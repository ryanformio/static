const { MongoClient, ObjectId } = require('mongodb');
const {URI, TEAM_MEMBER_RESOURCE_FORM_ID} = require('./constants');
const client = new MongoClient(URI);

const TEAM_ID = '650392b9c2469e42f0db0c37'

async function getTeamMembers(collection, teamId) {
    const query = {
        "data.team._id": new ObjectId(teamId),
        form: new ObjectId(TEAM_MEMBER_RESOURCE_FORM_ID)
    };
    const results = await collection.find(query).toArray();
    return results;
}

async function markAsDeleted(submissions, teamMembers) {
    const currentTimestamp = Date.now();
    const updatePromises = teamMembers.map(member => {
        return submissions.updateOne(
            { _id: member._id },
            { $set: { deleted: currentTimestamp } }
        );
    });

    await Promise.all(updatePromises);
}

async function main() {
    const submissions = client.db().collection('submissions');
    try {
        const teamMembers = await getTeamMembers(submissions, TEAM_ID);
        console.log('Team Members:', teamMembers);

        ///////////////////////////////////////////////////////////////////////////////////////
        // UNCOMMENT WHEN VALIDATED THE TEAM AND TEAM MEMBERS YOU'D LIKE TO DELETE ARE ACCURATE
        ///////////////////////////////////////////////////////////////////////////////////////
        await markAsDeleted(submissions, teamMembers);
        console.log('Marked team members as deleted');
        const updatedTeamMembers = await getTeamMembers(submissions, TEAM_ID);
        console.log('Updated Team Members:', updatedTeamMembers);
    } catch (e) {
        console.error('Error connecting to MongoDB', e);
    } finally {
        await client.close();
    }
}

main().catch(console.error);