const URI = "mongodb://localhost:27017/formio";
const TEAM_RESOURCE_FORM_ID = '64fd50033290c689a293aca6' // Team resource formId
const TEAM_MEMBER_RESOURCE_FORM_ID = '64fd50033290c689a293acac' // Team Member resource formId

module.exports = {
    URI,
    TEAM_MEMBER_RESOURCE_FORM_ID,
    TEAM_RESOURCE_FORM_ID
}