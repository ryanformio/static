const { MongoClient, ObjectId } = require('mongodb');
const {URI, TEAM_RESOURCE_FORM_ID} = require('./constants');
const client = new MongoClient(URI);

async function getDeletedTeams(collection) {
    const query = {
        deleted: { $exists: true, $ne: null },
        form: new ObjectId(TEAM_RESOURCE_FORM_ID)
    };
    const results = await collection.find(query).toArray();
    return results;
}

async function main() {
    const submissions = client.db().collection('submissions');
    try {
        const deletedTeams = await getDeletedTeams(submissions);
        console.log('Deleted Team(s):', deletedTeams);
    } catch (e) {
        console.error('Error connecting to MongoDB', e);
    } finally {
        await client.close();
    }
}

main().catch(console.error);