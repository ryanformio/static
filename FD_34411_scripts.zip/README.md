# Clean up Formio Teams & Team Members

Make sure to set your constants in `constants.js`

[Loom Script Walkthrough](https://www.loom.com/share/FD34411-Unauthorized-error-db8ae3ab757343c18b4518b8e35d75e5?sid=0afd5e47-ebcb-4753-91f3-d482c5200c6e)

```bash
## Install dependencies
npm install

## Find deleted teams
node deletedTeams.js

## Marked team members as deleted
node markedMembersDeleted.js
```